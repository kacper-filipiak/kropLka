import 'dart:async';
import 'dart:ffi';
import 'dart:io';
import 'dart:ui' as prefix0;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

//import 'package:flutter_camera_ml_vision/flutter_camera_ml_vision.dart';
import 'package:firebase_ml_vision/firebase_ml_vision.dart';
//import 'package:flutter_camera_ml_vision/flutter_camera_ml_vision.dart';
import 'package:flutter/services.dart';


void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        // This is the theme of your application.
        //
        // Try running your application with "flutter run". You'll see the
        // application has a blue toolbar. Then, without quitting the app, try
        // changing the primarySwatch below to Colors.green and then invoke
        // "hot reload" (press "r" in the console where you ran "flutter run",
        // or simply save your changes to "hot reload" in a Flutter IDE).
        // Notice that the counter didn't reset back to zero; the application
        // is not restarted.
        primarySwatch: Colors.amber,
      ),
      initialRoute: '/start',
      routes: {
        '/': (context) => MyHomePage(title: 'Kropelka'),
        '/second': (context)=>ProductEcoPageState(),
        '/start': (context)=> StartPage(),
      }
    );
  }
}

const String _path = 'Products';
Stream<QuerySnapshot> _serchStream (String _fild, _conditionData){
  return Firestore.instance.collection(_path).where(_fild, isEqualTo: _conditionData).snapshots();

}


class MyHomePage extends StatefulWidget {
  MyHomePage({Key key, this.title}) : super(key: key);

  // This widget is the home page of your application. It is stateful, meaning
  // that it has a State object (defined below) that contains fields that affect
  // how it looks.

  // This class is the configuration for the state. It holds the values (in this
  // case the title) provided by the parent (in this case the App widget) and
  // used by the build method of the State. Fields in a Widget subclass are
  // always marked "final".

  final String title;

  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  StreamController<QuerySnapshot> _streamController = new StreamController();
  Stream<QuerySnapshot> _firestoreList = Firestore.instance.collection(_path).snapshots();

  TextEditingController _textEditingController = new TextEditingController();



  int _counter = 0;

  List<Barcode> _barcodes;

  File _image;

  Future getImage() async {
    var image = await ImagePicker.pickImage(source: ImageSource.camera);
    print('....>');
      FirebaseVisionImage ourImage = FirebaseVisionImage.fromFile(image);
    print('....>');
      BarcodeDetector _barcodeDetector = FirebaseVision.instance
          .barcodeDetector();
    print('....>');
      List<Barcode> barcodes = await _barcodeDetector.detectInImage(ourImage);
    print('....>');
      setState(() {
        print('....>');
        _barcodes = barcodes;
        _image= image;
        print(_barcodes.first.displayValue);
        _firestoreList = _serchStream('barcode', _barcodes.first.displayValue);
      });
    }

  void _cancelSerch(){
    setState(() {
      //delete all input
      _firestoreList = Firestore.instance.collection(_path).snapshots();
      _textEditingController.text = "";
    });
  }

  void _dataGetFirebaseSnapshot() {
    setState(() {
      print('in funcion');
      //Search by text
      if(_textEditingController.text.isEmpty){
        _firestoreList = Firestore.instance.collection(_path).snapshots();
      }else {
        _firestoreList = Firestore.instance.collection(_path).where(
            'name', isEqualTo: _textEditingController.text).snapshots();
      }
      //TODO:make serching by more data
    });
  }

  @override
  Widget build(BuildContext context) {
    //
    // The Flutter framework has been optimized to make rerunning build methods
    // fast, so that you can just rebuild anything that needs updating rather
    // than having to individually change instances of widgets.
    return Scaffold(
      appBar: AppBar(
        // Here we take the value from the MyHomePage object that was created by
        // the App.build method, and use it to set our appbar title.
        title: Row(
          children: <Widget>[

            IconButton(
              icon: Icon(
                  Icons.search
              ),
              onPressed: _dataGetFirebaseSnapshot,

            ),

            SizedBox.fromSize(

              size: Size.fromWidth(MediaQuery.of(context).size.width/3),
              child:TextFormField(
                decoration: InputDecoration(
                    labelText: 'Serch'
                ),
                controller: _textEditingController,
              ),
            ),
            IconButton(
              icon: Icon(
                  Icons.cancel
              ),
              onPressed: _cancelSerch,

            ),

            _image == null
                ? Text('No image selected.')
                : Image.file(_image),
          ],
        ),

      ),
      body: Center(

        // Center is a layout widget. It takes a single child and positions it
        // in the middle of the parent.
          child: StreamBuilder<QuerySnapshot>(
              stream: _firestoreList,
              builder: (context,AsyncSnapshot<QuerySnapshot> snapshot) {
                if (!snapshot.hasData) return const Text('Loading...');
                print("...");
                return new ListView(
                    children: snapshot.data.documents.map((DocumentSnapshot document)
                    {
                      return new Padding(
                    padding: const EdgeInsets.all(8.0),
                    child:Container(
                      decoration: BoxDecoration(
                        color: Colors.tealAccent,
                        borderRadius: BorderRadius.all(Radius.circular(20.0),
                      ),
                      ),
                    child:ListTile(

                        title:Row(
                            children: [

                                SizedBox(
                                  height: 50,
                                  width: 50,



                                    child: Image.network(

                                document['image']
                              ),

                                ),

                              Column(
                                  children: [
                                    Text(document['name'],textScaleFactor: 2.0,),
                                    Text(document['barcode'],textScaleFactor: 2.0,),
                                    _barcodes != null?
                                    Text(_barcodes.first.displayValue):
                                      Text('no barcode'),

                                  ]
                              )
                            ]
                        ),
                        onTap: (){
                          Navigator.pushNamed(context, '/second',arguments: document);
                        },
                    ),
                    ),
                      );
                    }
                    ).toList()
                );
              }
          )
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: getImage,
        tooltip: 'Increment',
        child: Icon(Icons.photo_camera),
      ), // This trailing comma makes auto-formatting nicer for build methods.
    );
  }
}


class ProductEcoPageState extends StatefulWidget {
  ProductEcoPageState({Key key, this.title}) : super(key: key);

  // This widget is the home page of your application. It is stateful, meaning
  // that it has a State object (defined below) that contains fields that affect
  // how it looks.

  // This class is the configuration for the state. It holds the values (in this
  // case the title) provided by the parent (in this case the App widget) and
  // used by the build method of the State. Fields in a Widget subclass are
  // always marked "final".

  final String title;

  @override
  _ProductEcoPageState createState() => _ProductEcoPageState();
}
class _ProductEcoPageState extends State<ProductEcoPageState> {

  ImageProvider _imageProvider;
  //Stream<QuerySnapshot> _firestoreEcoList = Firestore.instance.collection('kropelka').document('oo6dMDsfCJ1Nx9GB77sd').collection('Coca-Cola').snapshots();

  @override
  Widget build(BuildContext context) {

    final DocumentSnapshot _document = ModalRoute.of(context).settings.arguments;
    Size size = MediaQuery.of(context).size;
    return Scaffold(
    appBar: AppBar(
        title: Container(
          child: Text("Second page"),
        )
    ),
    body: Stack(
        children: <Widget>[
           _document['image']!=null?
            Image.network(_document['image'],
            width: size.width,
            height: size.height,
            fit: BoxFit.fill,):
            Center(child: Text('no image'),),

          Column(


            children: <Widget>[
              SizedBox(
                height: 100,
                child: SizedBox(
                  height: _document['ratio']<50? 50.0-_document['ratio']+50.0:_document['ratio']*1.0,
                  width: _document['ratio']<50? 50.0-_document['ratio']+50.0:_document['ratio']*1.0,
                  child: Container(

                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color:_document['ratio']<50?Color.fromARGB(200, 50, 255, 50):Color.fromARGB(200, 255, 50, 50),

                    ),
                    child:Stack(children: <Widget>[
                       Center(child: Text(_document['ratio'].toString(),textScaleFactor: 2.0,)),

    ]
                    ),

                  ),
                ),
              ),
              Container(
                color: Colors.amber,
                child: SizedBox(

                  height: 50,
                  width: size.width,
                  child: Center(
                    child: Text(_document['name'],textScaleFactor: 2.0,),
                  ),
                ),
              ),
   Expanded(
   child: Padding(
     padding: const EdgeInsets.all(12.0),
     child: Container(
       decoration: BoxDecoration(
         color: Color.fromARGB(200, 255, 255, 255),
         borderRadius: BorderRadius.all(Radius.circular(20.0)),
       ),
       child: ListView(
        children: <Widget>
        [
          _secondItem(_document, 'green_water', Color.fromARGB(255, 55, 55, 255),Icons.format_color_reset,'Water used: '),
          _secondItem(_document, 'co2', Color.fromARGB(255, 55, 55, 100),Icons.cloud,'CO2 produced: '),
        ]
        ),
     ),
   )
    ),



    ]
      ),
            ],
          ),

      );



  }

}
Widget _secondItem(DocumentSnapshot _document, String fild, Color _color, IconData _icon,String text){
  return Padding(
    padding: const EdgeInsets.all(8.0),
    child: Center(
      child: Container(

        /*decoration: BoxDecoration(
          color: Colors.amber, //Color.fromARGB(200, 255, 255, 255),
          borderRadius: BorderRadius.all(Radius.circular(20.0),
          ),
        ),*/
        child: Column(
          children: <Widget>[
            Text(text+_document[fild].toString(),textScaleFactor: 2.0,),
            Icon(
              _icon,
              color: _color,
              size: _document[fild]*1.0,
            ),
          ],
        ),

      ),
    ),
  );
}

class StartPage extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body:
        Center(
        child: Column(
          children: <Widget>[
            SizedBox(
              height: MediaQuery.of(context).size.height/2 ,
            ),
            Text('Welcome',textScaleFactor: 2.0,),
            Row(
              children: <Widget>[
                FlatButton(
                  textColor: Colors.white,

                  color: Colors.amber,
                  child: Text('Serch',textScaleFactor: 2.0,),
                  onPressed:() {
                    Navigator.pushNamed(context, '/');
                  }
                ),
              ],
            ),
          ],
        ),
      ),

    );
  }
}